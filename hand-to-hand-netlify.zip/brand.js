'use strict';
(() => {
 const logoURL='/assets/brand/hand-to-hand.webp';
 const reduce=matchMedia('(prefers-reduced-motion: reduce)');
 const countryCard=document.querySelector('.country-card[data-country="lebanon"]');
 if(countryCard&&!document.body.dataset.experience){const symbol=document.createElement('img');symbol.className='country-brand-symbol';symbol.src='/assets/brand/hand-to-hand-symbol.webp';symbol.alt='';symbol.setAttribute('aria-hidden','true');symbol.width=576;symbol.height=576;symbol.loading='lazy';symbol.onerror=()=>symbol.remove();countryCard.append(symbol);}

 const normalise=path=>path.replace(/\/index\.html$/,'/').replace(/\/$/,'');
 let logoAvailable=false,busy=false,navigating=false,overlay=null,trigger=null,navigateTimer=null,safetyTimer=null,statusTimer=null;
 const previousInert=new Map();
 const probe=new Image();probe.onload=()=>{logoAvailable=true;document.documentElement.style.setProperty('--official-logo-ratio',probe.naturalWidth+'/'+probe.naturalHeight);};probe.onerror=()=>{logoAvailable=false;};probe.src='/assets/brand/hand-to-hand-display-320.webp';
 let warmed=false;function warmLogo(){if(warmed)return;warmed=true;const full=new Image();full.src=logoURL;}
 document.addEventListener('pointerover',event=>{if(event.target.closest('a[href*="/lebanon"]'))warmLogo();},{passive:true});
 document.addEventListener('focusin',event=>{if(event.target.closest('a[href*="/lebanon"]'))warmLogo();});
 function finish(restoreFocus=true){clearTimeout(navigateTimer);clearTimeout(safetyTimer);clearTimeout(statusTimer);overlay?.remove();overlay=null;previousInert.forEach((was,element)=>{element.inert=was;});previousInert.clear();busy=false;navigating=false;document.body.classList.remove('brand-is-transitioning');if(restoreFocus&&trigger?.isConnected)trigger.focus({preventScroll:true});}
 function ordinaryFailure(url){finish();const notice=document.createElement('p');notice.className='brand-navigation-notice';notice.setAttribute('role','status');notice.textContent='The collection couldn’t open. ';const link=document.createElement('a');link.href=url;link.dataset.brandTransition='skip';link.textContent='Open Lebanon';notice.append(link);document.querySelector('main')?.prepend(notice);}
 function enter(url){if(busy)return;busy=true;document.querySelector('.brand-navigation-notice')?.remove();
  // Start requesting the destination immediately; navigation remains native.
  const prefetch=document.createElement('link');prefetch.rel='prefetch';prefetch.as='document';prefetch.href=url.href;document.head.append(prefetch);
  fetch(url.href,{credentials:'same-origin',cache:'force-cache'}).catch(()=>{});
  overlay=document.createElement('div');overlay.className='brand-transition';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Entering the Lebanon collection');overlay.tabIndex=-1;
  const composition=document.createElement('div');composition.className='brand-composition';const stage=document.createElement('div');stage.className='brand-logo-stage';
  // Symbol layers isolate original bitmap pixels; the final composition is the untouched official artwork.
  for(const part of ['heart','upper-hand','lower-hand','wordmark','tagline','final']){const image=document.createElement('img');image.src=['heart','upper-hand','lower-hand'].includes(part)?'/assets/brand/transition-'+part+'.webp':logoURL;image.alt=part==='final'?'Hand to Hand — From their hands to yours':'';image.width=1774;image.height=887;image.className='brand-layer brand-layer-'+part;if(part!=='final')image.setAttribute('aria-hidden','true');image.onerror=()=>go();stage.append(image);}
  const status=document.createElement('p');status.className='brand-transition-status';status.setAttribute('role','status');status.textContent='Discovering Lebanon...';
  composition.append(stage,status);overlay.append(composition);
  function go(){if(!busy||navigating)return;navigating=true;clearTimeout(navigateTimer);clearTimeout(safetyTimer);clearTimeout(statusTimer);try{sessionStorage.setItem('handtohand:enter-lebanon',JSON.stringify({at:Date.now(),path:url.pathname}));}catch{}previousInert.forEach((was,element)=>{element.inert=was;});previousInert.clear();try{location.assign(url.href);safetyTimer=setTimeout(()=>{finish(false);},900);}catch{ordinaryFailure(url.href);}}
  [...document.body.children].filter(element=>!['SCRIPT','LINK','STYLE'].includes(element.tagName)).forEach(element=>{previousInert.set(element,element.inert);element.inert=true;});document.body.append(overlay);document.body.classList.add('brand-is-transitioning');overlay.focus({preventScroll:true});statusTimer=setTimeout(()=>status.classList.add('is-visible'),1580);navigateTimer=setTimeout(go,1800);safetyTimer=setTimeout(go,2400);
 }
 document.addEventListener('click',event=>{const a=event.target.closest('a[href]');if(!a||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.altKey||event.shiftKey||a.hasAttribute('download')||a.dataset.brandTransition==='skip'||(a.target&&a.target!=='_self'))return;let url;try{url=new URL(a.href,location.href);}catch{return;}if(url.origin!==location.origin||normalise(url.pathname)!=='/lebanon'||normalise(location.pathname)==='/lebanon')return;if(busy){event.preventDefault();return;}if(reduce.matches||!logoAvailable)return;event.preventDefault();trigger=a;enter(url);});
 document.addEventListener('click',event=>{if(event.target.closest('a,button,input,select,textarea'))return;const card=event.target.closest('.country-card[data-country="lebanon"]');card?.querySelector('a[href]')?.click();});
 window.addEventListener('pageshow',event=>{if(event.persisted){finish(false);document.documentElement.classList.remove('brand-arrival-pending');}});
 setTimeout(()=>document.documentElement.classList.remove('brand-arrival-pending'),650);
 // Small once-only image reveals fail open. Reduced-motion users receive static content.
 if(!reduce.matches&&'IntersectionObserver' in window){try{const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.remove('brand-reveal-pending');observer.unobserve(entry.target);}}),{rootMargin:'0px 0px 32px 0px'});document.querySelectorAll('.polaroids figure').forEach(element=>{element.classList.add('brand-reveal-pending');observer.observe(element);});setTimeout(()=>document.querySelectorAll('.brand-reveal-pending').forEach(element=>element.classList.remove('brand-reveal-pending')),1500);document.addEventListener('focusin',event=>event.target.closest('.brand-reveal-pending')?.classList.remove('brand-reveal-pending'));}catch{document.querySelectorAll('.brand-reveal-pending').forEach(element=>element.classList.remove('brand-reveal-pending'));}}
})();
